package com.example.myapplication2

class UserActivity {
}