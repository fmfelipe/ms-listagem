package com.example.myapplication2;

public class ConteudoTextos {
}
